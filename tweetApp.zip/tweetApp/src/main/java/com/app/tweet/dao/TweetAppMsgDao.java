package com.app.tweet.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.tweet.entity.TweetAppMsgDtl;

@Repository
public interface TweetAppMsgDao extends JpaRepository<TweetAppMsgDtl, Integer>{
	List<TweetAppMsgDtl> findByEmail(String email);
}

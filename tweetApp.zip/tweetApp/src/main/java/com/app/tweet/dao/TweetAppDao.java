package com.app.tweet.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.tweet.entity.TweetAppLogin;

@Repository
public interface TweetAppDao extends JpaRepository<TweetAppLogin, Integer> {

	Optional<TweetAppLogin> findByEmail(String email);
	Optional<TweetAppLogin> findByEmailAndPassword(String email, String password);
}

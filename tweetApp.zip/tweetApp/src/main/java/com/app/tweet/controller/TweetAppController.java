package com.app.tweet.controller;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import javax.net.ssl.SSLEngineResult.Status;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.tweet.entity.TweetAppLogin;
import com.app.tweet.entity.TweetAppMsgDtl;
import com.app.tweet.exception.ElementNotFoundException;
import com.app.tweet.service.TweetAppService;

@RestController
@RequestMapping(value="/api/tweetapp")
public class TweetAppController {

	@Autowired
	private TweetAppService tweetAppService;
	
	@PostMapping(value="/reg")
	public ResponseEntity<String> userRegistration(@RequestBody TweetAppLogin tweetAppLogin) {
		tweetAppLogin=tweetAppService.userRegistration(tweetAppLogin);
		HttpStatus status=null;
		String msg="";
		if(tweetAppLogin!=null && tweetAppLogin.getUser_id()!=null) {
			status=HttpStatus.CREATED;
			msg="User registerd successfully!";
		}else {
			status=HttpStatus.OK;
			msg="User registration failed. Please contact to the administration";
		}
		return new ResponseEntity<>(msg,status);
	}
	@PostMapping(value="/login")
	public ResponseEntity<String> userLogin(@RequestBody TweetAppLogin tweetAppLogin) {
		tweetAppLogin=tweetAppService.userLogin(tweetAppLogin);
		HttpStatus status=null;
		String msg="";
		if(tweetAppLogin!=null && tweetAppLogin.getUser_id()!=null) {
			status=HttpStatus.OK;
			msg="User log in successfully!";
		}else {
			status=HttpStatus.OK;
			msg="Wrong username or password.";
		}
		return new ResponseEntity<>(msg,status);
	}
	@PostMapping(value="/postTwt")
	public TweetAppMsgDtl postTwt(@RequestBody TweetAppMsgDtl tweetAppMsgDtl) {
		TweetAppLogin tweetAppLogin=tweetAppService.getUserDetails(tweetAppMsgDtl.getEmail());
		System.out.println("tweetAppLogin");
		HttpStatus status=null;
		String msg="";
		if(tweetAppLogin==null) {
			status=HttpStatus.OK;
			msg="";
			throw new ElementNotFoundException("User is not registered.");
		}else if(tweetAppLogin!=null && (tweetAppLogin.getLogin_status()==null || tweetAppLogin.getLogin_status().equals("0"))) {
			status=HttpStatus.OK;
			msg="User is not log in.";
			
			throw new ElementNotFoundException("User is not log in.");
		}else {
			LocalDate todayKolkata = LocalDate.now(ZoneId.of("Asia/Kolkata"));
			tweetAppMsgDtl.setUser_id(tweetAppLogin.getUser_id());
			tweetAppMsgDtl.setUser_twt_date(todayKolkata.toString());
			tweetAppMsgDtl=tweetAppService.postTwt(tweetAppMsgDtl);
		}
		
		return tweetAppMsgDtl;
	}
	/*
	 * @PostMapping(value="/postTwt") public TweetAppMsgDtl postTwt(@RequestBody
	 * TweetAppMsgDtl tweetAppMsgDtl) { return
	 * tweetAppService.postTwt(tweetAppMsgDtl); }
	 */
	@GetMapping(value="/userTwt/{email}")
	public List<TweetAppMsgDtl> getUserAllTwt(@PathVariable("email")String email) {
		return tweetAppService.getUserAllTwt(email);
	}
	@GetMapping(value="/allUserTwt")
	public List<TweetAppMsgDtl> getallUserTwt() {
		return tweetAppService.getallUserTwt();
	}
	@PostMapping(value="/changePwd")
	public ResponseEntity<String> updateUserPwd(@RequestBody TweetAppLogin tweetAppLogin) {
		tweetAppLogin=tweetAppService.updateUserPwd(tweetAppLogin);
		HttpStatus status=null;
		String msg="";
		if(tweetAppLogin!=null && tweetAppLogin.getUser_id()!=null) {
			status=HttpStatus.OK;
			msg="User password changed successfully!";
		}else {
			status=HttpStatus.OK;
			msg="Wrong username or password.";
		}
		return new ResponseEntity<>(msg,status);
	}
	
}

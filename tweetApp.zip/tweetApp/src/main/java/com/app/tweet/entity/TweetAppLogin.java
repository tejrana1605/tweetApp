package com.app.tweet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tweet_app_user_login")
public class TweetAppLogin {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_id")
	Integer user_id;
	@Column(name="user_first_name", nullable=false)
	String user_first_name;
	@Column(name="user_last_name", nullable=false)
	String user_last_name;
	@Column(name="email", nullable=false)
	String email;
	@Column(name="password", nullable=false)
	String password;
	@Column(name="login_status")
	String login_status;
	
	public TweetAppLogin(){
		
	}
	public TweetAppLogin(Integer user_id, String user_first_name, String user_last_name, String email, String password,
			String login_status) {
		super();
		this.user_id = user_id;
		this.user_first_name = user_first_name;
		this.user_last_name = user_last_name;
		this.email = email;
		this.password = password;
		this.login_status = login_status;
	}
	
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getUser_first_name() {
		return user_first_name;
	}
	public void setUser_first_name(String user_first_name) {
		this.user_first_name = user_first_name;
	}
	public String getUser_last_name() {
		return user_last_name;
	}
	public void setUser_last_name(String user_last_name) {
		this.user_last_name = user_last_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLogin_status() {
		return login_status;
	}
	public void setLogin_status(String login_status) {
		this.login_status = login_status;
	}
	
}

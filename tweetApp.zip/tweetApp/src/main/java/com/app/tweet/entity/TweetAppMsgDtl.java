package com.app.tweet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="twt_app_user_twt")
public class TweetAppMsgDtl {
	@Id
	@Column(name="user_id")
	Integer user_id;
	@Column(name="user_email", nullable=false)
	String email;
	@Column(name="user_twt")
	String user_twt;
	@Column(name="user_twt_date", nullable=false)
	String user_twt_date;
	
	public TweetAppMsgDtl(){
		
	}
	public TweetAppMsgDtl(Integer user_id, String email, String user_twt, String user_twt_date) {
		super();
		this.user_id = user_id;
		this.email = email;
		this.user_twt = user_twt;
		this.user_twt_date = user_twt_date;
	}
	
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getEmail() {
		return email;
	}
	public void setUser_email(String email) {
		this.email = email;
	}
	public String getUser_twt() {
		return user_twt;
	}
	public void setUser_twt(String user_twt) {
		this.user_twt = user_twt;
	}
	public String getUser_twt_date() {
		return user_twt_date;
	}
	public void setUser_twt_date(String user_twt_date) {
		this.user_twt_date = user_twt_date;
	}
	
}
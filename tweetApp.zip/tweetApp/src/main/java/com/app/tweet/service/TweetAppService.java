package com.app.tweet.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.tweet.dao.TweetAppDao;
import com.app.tweet.dao.TweetAppMsgDao;
import com.app.tweet.entity.TweetAppLogin;
import com.app.tweet.entity.TweetAppMsgDtl;
import com.app.tweet.exception.BadRequestException;
import com.app.tweet.exception.ElementNotFoundException;

@Service
public class TweetAppService {
	
	@Autowired
	private TweetAppDao tweetAppDao;
	
	@Autowired
	private TweetAppMsgDao tweetAppMsgDao;

	public TweetAppLogin userRegistration(TweetAppLogin tweetAppLogin) {
		System.out.println(tweetAppLogin.toString());
		System.out.println("twtAppLogin1");
		Optional<TweetAppLogin> twtAppLogin=tweetAppDao.findByEmail(tweetAppLogin.getEmail());
		System.out.println("twtAppLogin");
		if(twtAppLogin.isPresent()) {
			throw new BadRequestException("Using dublicate user mail.");
		}
 		return tweetAppDao.save(tweetAppLogin);
	}
	public TweetAppLogin userLogin(TweetAppLogin tweetAppLogin) {
		Optional<TweetAppLogin> twtAppLogin=tweetAppDao.findByEmailAndPassword(tweetAppLogin.getEmail(), tweetAppLogin.getPassword());
		TweetAppLogin twtApp=null;
		if(twtAppLogin.isPresent()) {
			twtApp=twtAppLogin.get();
			twtApp.setLogin_status("1");
		}else {
			throw new ElementNotFoundException("The user not registered");
		}
		System.out.println(tweetAppLogin.toString());
 		return tweetAppDao.save(twtApp);
	}
	
	public TweetAppLogin getUserDetails(String email) {
		Optional<TweetAppLogin> twtAppLogin=tweetAppDao.findByEmail(email);
		System.out.println("twtAppLogin");
		TweetAppLogin tweetAppLogin=null;
		if(twtAppLogin.isPresent()) {
			tweetAppLogin=twtAppLogin.get();
		}else {
			tweetAppLogin=null;
		}
		return tweetAppLogin;
	}
	public TweetAppMsgDtl postTwt(TweetAppMsgDtl tweetAppMsgDtl) {
		
 		return tweetAppMsgDao.save(tweetAppMsgDtl);
	}
	public List<TweetAppMsgDtl> getUserAllTwt(String email) { 
		List<TweetAppMsgDtl> twtAppLogin=tweetAppMsgDao.findByEmail(email);
		return twtAppLogin;
	}
	public List<TweetAppMsgDtl> getallUserTwt() { 
		List<TweetAppMsgDtl> twtApp=tweetAppMsgDao.findAll();
		TweetAppMsgDtl tweetAppMsgDtl=null;
		if(twtApp==null) {
			twtApp=null;
		}
		return twtApp;
	}
	public TweetAppLogin updateUserPwd(TweetAppLogin tweetAppLogin) {
		Optional<TweetAppLogin> twtAppLogin=tweetAppDao.findByEmail(tweetAppLogin.getEmail());
		TweetAppLogin twtApp=null;
		if(twtAppLogin.isPresent()) {
			twtApp=twtAppLogin.get();
			twtApp.setPassword(tweetAppLogin.getPassword());
		}else {
			throw new ElementNotFoundException("The user not registered");
		}
		System.out.println(tweetAppLogin.toString());
 		return tweetAppDao.save(twtApp);
	}
}
